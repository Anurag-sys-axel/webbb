# CO-Resolve
A portal which escalated your issues and makes sure you are being heard. Together we can get out of this pandemic !
![image](https://user-images.githubusercontent.com/79207707/123532285-8c281480-d729-11eb-93db-a8ffdebbd41e.png)

Features:
- Home page provides valuable information for anyone who still may be ignorant or unaware about it. It's necessary to follow the guidelines to protect yourself and the people you love.
- You can file your complaints, and issues with the portal... we make sure to escalate them to the higher authorities.
- You can upvote similar issues, which will help us recognise the most immediate ones and will be resolved first.

## Get useful info
![image](https://user-images.githubusercontent.com/79207707/123532348-1cfef000-d72a-11eb-9563-a21d6cbb791e.png)

## File your issues
![image](https://user-images.githubusercontent.com/79207707/123532415-867efe80-d72a-11eb-936c-979cf03aecbd.png)

## Find and Upvote other issues
![image](https://user-images.githubusercontent.com/79207707/123532429-9eef1900-d72a-11eb-8482-62c839d8376c.png)
![image](https://user-images.githubusercontent.com/79207707/123532494-2472c900-d72b-11eb-9eee-755dac798175.png)
 
 ## Search for issues from 'escalate'
 ![image](https://user-images.githubusercontent.com/79207707/123532477-f7beb180-d72a-11eb-98a4-b2654b626da5.png)
## Access from anywhere
![image](https://user-images.githubusercontent.com/79207707/123532563-cdb9bf00-d72b-11eb-92bb-a496fee30ad3.png)
